// ============================================================================
// GENRE MECHANICS PROFILES
//
// Lightweight genre-specific knobs to make each mode feel distinct in UI
// and core derived stats (HP, currency naming, etc.).
//
// This is intentionally conservative: it upgrades "feel" without
// rewriting the entire simulation in one pass.
// ============================================================================

import type { GameGenre } from '@/types/genreData';
import type { CharacterStats } from '@/types/rpgCharacter';

export interface GenreMechanicsProfile {
  // Health tuning
  baseHP: number;            // baseline at level 1
  conMultiplier: number;     // how much constitution boosts HP
  levelBonus: number;        // HP added per level

  // UI flavor
  currencyName: string;
  currencyIcon: string;
  combatFocus: number;       // 0..1 (used for minor UI emphasis)
  needsFocus: number;        // 0..1
  techFocus: number;         // 0..1
}

export const GENRE_MECHANICS: Record<GameGenre, GenreMechanicsProfile> = {
  war: {
    baseHP: 70,              // more lethal; armor + cover matter
    conMultiplier: 2,
    levelBonus: 6,
    currencyName: 'Supplies',
    currencyIcon: '🎖️',
    combatFocus: 1,
    needsFocus: 0.4,
    techFocus: 0.3,
  },
  modern_life: {
    baseHP: 100,             // grounded, familiar
    conMultiplier: 2,
    levelBonus: 4,
    currencyName: 'Dollars',
    currencyIcon: '$',
    combatFocus: 0.2,
    needsFocus: 1,
    techFocus: 0.3,
  },
  cyberpunk: {
    baseHP: 90,
    conMultiplier: 2,
    levelBonus: 5,
    currencyName: 'Eddies',
    currencyIcon: '€$',
    combatFocus: 0.9,
    needsFocus: 0.3,
    techFocus: 1,
  },
  fantasy: {
    baseHP: 95,
    conMultiplier: 3,
    levelBonus: 7,
    currencyName: 'Gold',
    currencyIcon: '🪙',
    combatFocus: 0.7,
    needsFocus: 0.3,
    techFocus: 0.1,
  },
  scifi: {
    baseHP: 90,
    conMultiplier: 2,
    levelBonus: 5,
    currencyName: 'Credits',
    currencyIcon: '₵',
    combatFocus: 0.6,
    needsFocus: 0.4,
    techFocus: 0.8,
  },
  horror: {
    baseHP: 65,
    conMultiplier: 2,
    levelBonus: 4,
    currencyName: 'Cash',
    currencyIcon: '$',
    combatFocus: 0.4,
    needsFocus: 0.6,
    techFocus: 0.2,
  },
  mystery: {
    baseHP: 85,
    conMultiplier: 2,
    levelBonus: 4,
    currencyName: 'Cash',
    currencyIcon: '$',
    combatFocus: 0.3,
    needsFocus: 0.5,
    techFocus: 0.3,
  },
  noir: {
    baseHP: 85,
    conMultiplier: 2,
    levelBonus: 4,
    currencyName: 'Cash',
    currencyIcon: '$',
    combatFocus: 0.4,
    needsFocus: 0.4,
    techFocus: 0.2,
  },
  western: {
    baseHP: 90,
    conMultiplier: 2,
    levelBonus: 5,
    currencyName: 'Dollars',
    currencyIcon: '$',
    combatFocus: 0.7,
    needsFocus: 0.4,
    techFocus: 0.1,
  },
  pirate: {
    baseHP: 95,
    conMultiplier: 2,
    levelBonus: 6,
    currencyName: 'Doubloons',
    currencyIcon: '🪙',
    combatFocus: 0.7,
    needsFocus: 0.4,
    techFocus: 0.2,
  },
  postapoc: {
    baseHP: 80,
    conMultiplier: 2,
    levelBonus: 5,
    currencyName: 'Caps',
    currencyIcon: '🔘',
    combatFocus: 0.8,
    needsFocus: 0.8,
    techFocus: 0.4,
  },
  custom: {
    baseHP: 90,
    conMultiplier: 2,
    levelBonus: 5,
    currencyName: 'Coins',
    currencyIcon: '🪙',
    combatFocus: 0.5,
    needsFocus: 0.5,
    techFocus: 0.5,
  },
};

export function getGenreMechanicsProfile(genre: GameGenre): GenreMechanicsProfile {
  return GENRE_MECHANICS[genre] || GENRE_MECHANICS.custom;
}

// Blend in up to 2 secondary genres using their blendStrength (0..50)
export function blendGenreMechanics(
  primary: GameGenre,
  secondaries: Array<{ genreId: string; blendStrength: number }> = []
): GenreMechanicsProfile {
  const base = getGenreMechanicsProfile(primary);
  const cappedSecondaries = secondaries.slice(0, 2);

  const totalStrength = Math.min(
    50,
    cappedSecondaries.reduce((s, g) => s + Math.max(0, Math.min(50, g.blendStrength)), 0)
  );
  if (totalStrength <= 0) return base;

  // Weighted average across numeric fields. Currency stays primary.
  let hpBase = base.baseHP;
  let conMult = base.conMultiplier;
  let lvlBonus = base.levelBonus;
  let combat = base.combatFocus;
  let needs = base.needsFocus;
  let tech = base.techFocus;

  const wPrimary = 100 - totalStrength;
  hpBase *= wPrimary;
  conMult *= wPrimary;
  lvlBonus *= wPrimary;
  combat *= wPrimary;
  needs *= wPrimary;
  tech *= wPrimary;

  for (const sg of cappedSecondaries) {
    const w = Math.max(0, Math.min(50, sg.blendStrength));
    const g = (GENRE_MECHANICS as any)[sg.genreId] as GenreMechanicsProfile | undefined;
    if (!g || w === 0) continue;
    hpBase += g.baseHP * w;
    conMult += g.conMultiplier * w;
    lvlBonus += g.levelBonus * w;
    combat += g.combatFocus * w;
    needs += g.needsFocus * w;
    tech += g.techFocus * w;
  }

  const denom = 100;
  return {
    ...base,
    baseHP: Math.round(hpBase / denom),
    conMultiplier: Math.round((conMult / denom) * 10) / 10,
    levelBonus: Math.round(lvlBonus / denom),
    combatFocus: Math.round((combat / denom) * 100) / 100,
    needsFocus: Math.round((needs / denom) * 100) / 100,
    techFocus: Math.round((tech / denom) * 100) / 100,
  };
}

export function calculateGenreMaxHealth(
  stats: CharacterStats,
  level: number,
  primaryGenre: GameGenre,
  secondaries: Array<{ genreId: string; blendStrength: number }> = []
): number {
  const p = blendGenreMechanics(primaryGenre, secondaries);
  const con = Math.max(0, stats.constitution || 0);
  const lvl = Math.max(1, level || 1);
  // Keep it sane and predictable.
  const hp = p.baseHP + Math.floor(con * p.conMultiplier) + (lvl - 1) * p.levelBonus;
  return Math.max(30, Math.min(300, hp));
}
