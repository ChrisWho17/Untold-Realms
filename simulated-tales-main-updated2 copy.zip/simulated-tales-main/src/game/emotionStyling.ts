// ============================================================================
// EMOTION STYLING - genre-specific wrappers for dialogue emotion tags
//
// User request: emotions are “standard emotions wrapped in different punctuation”.
// This module provides a single formatter that the UI can use.
// ============================================================================

import type { GameGenre } from '@/types/genreData';

export type CoreEmotion =
  | 'neutral'
  | 'happy'
  | 'sad'
  | 'angry'
  | 'annoyed'
  | 'fearful'
  | 'suspicious'
  | 'depressed'
  | 'confident'
  | 'flirtatious'
  | 'tired'
  | 'injured'
  | 'panicked';

// Map sloppy/typo inputs to a core emotion.
export function normalizeEmotion(raw: string | undefined | null): CoreEmotion | null {
  if (!raw) return null;
  const v = raw.trim().toLowerCase();
  if (!v) return null;
  const cleaned = v.replace(/[^a-z]/g, '');
  const alias: Record<string, CoreEmotion> = {
    neutr: 'neutral',
    neutral: 'neutral',
    calm: 'neutral',
    happy: 'happy',
    glad: 'happy',
    joy: 'happy',
    sad: 'sad',
    upset: 'sad',
    angry: 'angry',
    angrly: 'angry',
    mad: 'angry',
    furious: 'angry',
    annoyed: 'annoyed',
    irrit: 'annoyed',
    irritated: 'annoyed',
    fearful: 'fearful',
    fear: 'fearful',
    scared: 'fearful',
    suspicious: 'suspicious',
    sus: 'suspicious',
    depressed: 'depressed',
    despair: 'depressed',
    confident: 'confident',
    smug: 'confident',
    flirty: 'flirtatious',
    flirtatious: 'flirtatious',
    tired: 'tired',
    exhausted: 'tired',
    injured: 'injured',
    hurt: 'injured',
    panicked: 'panicked',
    panic: 'panicked',
  };
  return alias[cleaned] || (cleaned as CoreEmotion);
}

type Wrapper = { prefix: string; suffix: string; upper?: boolean };

const WRAPPERS: Record<GameGenre | 'default', Wrapper> = {
  war: { prefix: '[', suffix: ']', upper: true },
  modern_life: { prefix: '(', suffix: ')', upper: false },
  cyberpunk: { prefix: '<', suffix: '>', upper: true },
  fantasy: { prefix: '{', suffix: '}', upper: false },
  horror: { prefix: '⟦', suffix: '⟧', upper: true },
  mystery: { prefix: '“', suffix: '”', upper: false },
  noir: { prefix: '⋯', suffix: '⋯', upper: false },
  western: { prefix: '〔', suffix: '〕', upper: true },
  pirate: { prefix: '⟪', suffix: '⟫', upper: true },
  scifi: { prefix: '⟨', suffix: '⟩', upper: true },
  postapoc: { prefix: '⟦', suffix: '⟧', upper: true },
  custom: { prefix: '(', suffix: ')', upper: false },
  default: { prefix: '(', suffix: ')', upper: false },
};

export function formatEmotionTag(genre: GameGenre, emotion: CoreEmotion | null): string {
  if (!emotion || emotion === 'neutral') return '';
  const w = WRAPPERS[genre] || WRAPPERS.default;
  const label = w.upper ? emotion.toUpperCase() : emotion;
  return `${w.prefix}${label}${w.suffix}`;
}

export function formatSpeakerLabel(genre: GameGenre, speakerName: string, emotion: CoreEmotion | null): string {
  const tag = formatEmotionTag(genre, emotion);
  return tag ? `${speakerName} ${tag}` : speakerName;
}
