import React from 'react';
import { SoundSeeder } from '@/components/admin/SoundSeeder';

export default function SoundSeederPage() {
  return (
    <div className="min-h-screen bg-background p-8">
      <SoundSeeder />
    </div>
  );
}
