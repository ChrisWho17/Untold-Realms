import { CampaignGameWrapper } from '@/components/adventure/CampaignGameWrapper';

const Index = () => {
  return <CampaignGameWrapper />;
};

export default Index;