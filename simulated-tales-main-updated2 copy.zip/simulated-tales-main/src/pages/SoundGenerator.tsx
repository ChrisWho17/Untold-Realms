import { SoundGenerator } from '@/components/admin/SoundGenerator';

export default function SoundGeneratorPage() {
  return <SoundGenerator />;
}
