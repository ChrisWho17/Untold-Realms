import { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { FolderOpen, Home, RotateCcw } from 'lucide-react';

interface AdventureShellProps {
  stepLabel: string;
  children: ReactNode;
  /** Jump to scenario selection */
  onHome?: () => void;
  /** Full reset (unload campaign + clear local save) */
  onRestart?: () => void;
  /** Optional extra buttons on the right */
  rightSlot?: ReactNode;
  className?: string;
}

/**
 * Lightweight wrapper used for non-playing phases.
 * Goal: keep the UI present (header + navigation) even during setup screens.
 */
export function AdventureShell({
  stepLabel,
  children,
  onHome,
  onRestart,
  rightSlot,
  className,
}: AdventureShellProps) {
  const navigate = useNavigate();

  return (
    <div className={cn('min-h-screen flex flex-col', className)}>
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/70 backdrop-blur-md">
        <div className="mx-auto max-w-5xl px-4 py-3 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="font-display tracking-wide text-foreground/90">
              Simulated Tales
            </div>
            <div className="text-xs text-muted-foreground/80 truncate">{stepLabel}</div>
          </div>

          <div className="flex items-center gap-2">
            {onHome && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onHome}
                className="frosted-button"
                title="Back to scenario selection"
              >
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
            )}

            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/campaigns')}
              className="frosted-button"
              title="Open Campaigns"
            >
              <FolderOpen className="w-4 h-4 mr-2" />
              Campaigns
            </Button>

            {onRestart && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onRestart}
                className="frosted-button text-muted-foreground/80 hover:text-destructive"
                title="Reset"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            )}

            {rightSlot}
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>
    </div>
  );
}
