import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatSpeakerLabel, normalizeEmotion } from '@/game/emotionStyling';
import type { GameGenre } from '@/types/genreData';
import { ensureNpcPortrait } from '@/services/npcPortraitService';
import { getNPCRegistry } from '@/game/npcIdentityRegistry';

interface DialogueTurnProps {
  campaignId: string;
  genre: GameGenre;
  npcId: string;
  speakerName: string;
  emotion?: string | null;
  text: string;
  // Used to render speaker names as links elsewhere
  speakerElement?: ReactNode;
}

export function DialogueTurn({
  campaignId,
  genre,
  npcId,
  speakerName,
  emotion,
  text,
  speakerElement,
}: DialogueTurnProps) {
  const coreEmotion = useMemo(() => normalizeEmotion(emotion), [emotion]);
  const [portraitUrl, setPortraitUrl] = useState<string | null>(null);
  const [portraitError, setPortraitError] = useState<string | null>(null);

  const registry = useMemo(() => getNPCRegistry(), []);
  const npc = registry.npcs[npcId];

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (npc?.portrait) {
          if (!cancelled) setPortraitUrl(npc.portrait);
          return;
        }
        const url = await ensureNpcPortrait({
          campaignId,
          npcId,
          npcName: speakerName,
          genre,
          npcBio: npc?.backstory,
          visualHints: npc?.appearance,
        });
        // Mirror into registry so other UIs can reuse it
        if (npc) npc.portrait = url;
        if (!cancelled) setPortraitUrl(url);
      } catch (e: any) {
        if (!cancelled) {
          setPortraitError(e?.message || 'Failed to generate portrait');
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [campaignId, npcId, genre, speakerName]);

  const label = formatSpeakerLabel(genre, speakerName, coreEmotion);

  // Tiny “stat card” feel without overwhelming the log.
  const statPills = useMemo(() => {
    const pills: Array<{ label: string; value: string }> = [];
    if (!npc) return pills;
    if (npc.occupation) pills.push({ label: 'Role', value: npc.occupation });
    if (npc.faction) pills.push({ label: 'Faction', value: npc.faction });
    if (npc.personality?.summary) pills.push({ label: 'Vibe', value: npc.personality.summary });
    return pills.slice(0, 3);
  }, [npcId]);

  return (
    <Card className="my-4 overflow-hidden border border-primary/25 bg-background/40 backdrop-blur">
      <div className="flex gap-3 p-3">
        <div className="w-16 shrink-0">
          {portraitUrl ? (
            <img
              src={portraitUrl}
              alt={speakerName}
              className="w-16 h-20 rounded-lg object-cover border border-white/10"
              loading="lazy"
            />
          ) : (
            <div className="w-16 h-20 rounded-lg bg-muted/30 border border-white/10 flex items-center justify-center text-xs text-muted-foreground">
              {portraitError ? 'No img' : '...'}
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <div className="font-semibold text-foreground/95">
              {speakerElement ?? label}
              {!speakerElement && coreEmotion && coreEmotion !== 'neutral' && (
                <span className="sr-only"> {coreEmotion}</span>
              )}
            </div>
            {coreEmotion && coreEmotion !== 'neutral' && (
              <Badge variant="secondary" className="text-xs opacity-90">
                {coreEmotion}
              </Badge>
            )}
          </div>

          {statPills.length > 0 && (
            <div className="mt-1 flex flex-wrap gap-1.5">
              {statPills.map((p, i) => (
                <span
                  key={`${npcId}-pill-${i}`}
                  className="text-[11px] px-2 py-0.5 rounded-full bg-muted/30 border border-white/10 text-muted-foreground"
                  title={`${p.label}: ${p.value}`}
                >
                  <span className="text-foreground/70">{p.label}:</span> {p.value}
                </span>
              ))}
            </div>
          )}

          <p className="mt-2 text-foreground/90 leading-relaxed">
            <span className="italic">&ldquo;{text}&rdquo;</span>
          </p>
        </div>
      </div>
    </Card>
  );
}
