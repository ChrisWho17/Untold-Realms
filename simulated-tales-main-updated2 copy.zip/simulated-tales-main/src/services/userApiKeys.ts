// ============================================================================
// USER API KEY STORE - runtime keys stored in localStorage (client-side)
//
// Notes:
// - Keys are stored only in the user's browser.
// - We intentionally keep this tiny and dependency-free.
// ============================================================================

export type ApiKeyProvider = 'together' | 'openai' | 'anthropic' | 'google';

const KEY_PREFIX = 'lwe_api_key:';

function storageKey(provider: ApiKeyProvider): string {
  return `${KEY_PREFIX}${provider}`;
}

export function getApiKey(provider: ApiKeyProvider): string | null {
  try {
    const v = localStorage.getItem(storageKey(provider));
    return v && v.trim().length > 0 ? v : null;
  } catch {
    return null;
  }
}

export function setApiKey(provider: ApiKeyProvider, key: string): void {
  try {
    const trimmed = key.trim();
    if (!trimmed) {
      localStorage.removeItem(storageKey(provider));
      return;
    }
    localStorage.setItem(storageKey(provider), trimmed);
  } catch {
    // ignore
  }
}

export function hasApiKey(provider: ApiKeyProvider): boolean {
  return !!getApiKey(provider);
}

export function maskKey(key: string | null, visibleTail: number = 4): string {
  if (!key) return '';
  const t = key.trim();
  if (t.length <= visibleTail) return '•'.repeat(Math.max(0, t.length));
  return `${'•'.repeat(Math.max(0, t.length - visibleTail))}${t.slice(-visibleTail)}`;
}
