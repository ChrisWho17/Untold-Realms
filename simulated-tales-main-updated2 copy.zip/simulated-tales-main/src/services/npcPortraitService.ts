// ============================================================================
// NPC PORTRAIT SERVICE - stable portraits per NPC per campaign
//
// Goals:
// - Generate portraits using the user's API keys (Together/FLUX).
// - Cache per campaign so portraits don't change on refresh.
// - Provide a single callsite for UI components.
// ============================================================================

import { generatePortraitWithFlux } from './fluxImageGeneration';
import { NPC_PORTRAIT_STORAGE_PREFIX } from '@/types/campaign';
import type { GameGenre } from '@/types/genreData';

export type PortraitCache = Record<string, string>; // npcId -> url/dataUrl

function keyForCampaign(campaignId: string): string {
  return `${NPC_PORTRAIT_STORAGE_PREFIX}${campaignId}`;
}

export function loadPortraitCache(campaignId: string): PortraitCache {
  try {
    const raw = localStorage.getItem(keyForCampaign(campaignId));
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function savePortraitCache(campaignId: string, cache: PortraitCache): void {
  try {
    localStorage.setItem(keyForCampaign(campaignId), JSON.stringify(cache));
  } catch {
    // ignore
  }
}

export function getCachedPortrait(campaignId: string, npcId: string): string | null {
  const cache = loadPortraitCache(campaignId);
  return cache[npcId] || null;
}

export function setCachedPortrait(campaignId: string, npcId: string, portraitUrl: string): void {
  const cache = loadPortraitCache(campaignId);
  cache[npcId] = portraitUrl;
  savePortraitCache(campaignId, cache);
}

// A small, genre-tinted prompt builder.
export function buildNpcPortraitPrompt(params: {
  npcName: string;
  npcBio?: string;
  genre: GameGenre;
  visualHints?: string;
  styleHint?: string;
}): string {
  const { npcName, npcBio, genre, visualHints, styleHint } = params;

  const baseStyle =
    genre === 'war'
      ? 'gritty wartime portrait, documentary realism, muted palette, mud and wear'
      : genre === 'modern_life'
        ? 'modern candid portrait, natural lighting, realistic street photography'
        : genre === 'cyberpunk'
          ? 'cyberpunk character portrait, neon rim lighting, chrome details, rain, cinematic'
          : 'cinematic character portrait, consistent face, high detail, realistic';

  const safeDefaults = 'single person, facing camera, head-and-shoulders, sharp focus, 3/4 view, no text, no watermark';
  const bio = npcBio ? `Background: ${npcBio}.` : '';
  const hints = visualHints ? `Details: ${visualHints}.` : '';
  const extra = styleHint ? `Style: ${styleHint}.` : '';

  return `Character portrait of ${npcName}. ${bio} ${hints} ${extra} ${baseStyle}. ${safeDefaults}`.trim();
}

export async function ensureNpcPortrait(params: {
  campaignId: string;
  npcId: string;
  npcName: string;
  genre: GameGenre;
  npcBio?: string;
  visualHints?: string;
  styleHint?: string;
}): Promise<string> {
  const cached = getCachedPortrait(params.campaignId, params.npcId);
  if (cached) return cached;

  const prompt = buildNpcPortraitPrompt({
    npcName: params.npcName,
    npcBio: params.npcBio,
    genre: params.genre,
    visualHints: params.visualHints,
    styleHint: params.styleHint,
  });

  const url = await generatePortraitWithFlux(prompt);
  setCachedPortrait(params.campaignId, params.npcId, url);
  return url;
}
